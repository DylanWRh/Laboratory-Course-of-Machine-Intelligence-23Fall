/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  TerrainAppDelegate.mm

#import "TerrainAppDelegate.h"
#import "EditPanel.h"
#import "LightBox.h"

@implementation TerrainAppDelegate

- (IBAction)deselect:(id)sender
{
	[[EditPanel sharedEditPanel] deselect];
}

- (IBAction)selectTool:(id)sender
{
	[[EditPanel sharedEditPanel] setTool: [sender tag]];
}

- (IBAction)showEditPanel:(id)sender
{
	[[EditPanel sharedEditPanel] showWindow: sender]; 
}

- (IBAction)showLightBox:(id)sender
{
	[[LightBox sharedLightBox] showWindow: sender]; 
}

- (BOOL)applicationShouldOpenUntitledFile:(NSApplication *)sender
{
	return NO;
}

- (void)applicationWillFinishLaunching:(NSNotification *)aNotification
{
	[self showEditPanel: self];
}

- (BOOL)validateMenuItem:(id <NSMenuItem>)item
{
	if ([item action] == @selector(selectTool:)) {
		int tool = [[EditPanel sharedEditPanel] tool];
		[item setState: ([item tag] == tool) ? NSOnState : NSOffState];
		return YES;
	}
	
	return YES;
}

@end
