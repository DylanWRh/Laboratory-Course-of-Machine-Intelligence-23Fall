/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  LightBox.mm

#import "LightBox.h"

#import <OpenGL/gl.h>

@implementation LightBox

+ (id)sharedLightBox {
    static LightBox *lightBox = nil;

    if (!lightBox) {
        lightBox = [[LightBox alloc] init];
    }

    return lightBox;
}

- (id)init {
    self = [self initWithWindowNibName:@"LightBox"];
    if (self) {
        [self setWindowFrameAutosaveName:@"LightBox"];
		[self reset];
    }
    return self;
}


- (void) reset
{
	ambientIntensity	= 0.0;
	
	lightPositionX		= -1.0;
	lightPositionY		= -9.0;
	lightPositionZ		= 7.0;
	lightDirectional	= YES;
	
	lightAmbient		= 0.50;
	lightDiffuse		= 1.00;
	lightSpecular		= 0.25;
	
	materialAmbient		= 0.50;
	materialDiffuse		= 1.00;
	materialSpecular	= 0.25;
	materialShininess	= 12.0;
}

- (void)setLightsAndMaterial
{
	glEnable(GL_LIGHTING);
	
	GLfloat lightModelAmb[4] =
	{ ambientIntensity, ambientIntensity, ambientIntensity, 1.00F };
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lightModelAmb);

	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 1);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 1);

	GLfloat light0Pos[4] = {
		lightPositionX, 
		lightPositionY,
		lightPositionZ,
		lightDirectional ? 0.0 : 1.0 };
	glLightfv(GL_LIGHT0, GL_POSITION, light0Pos);

	GLfloat light0Amb[4] = { lightAmbient, lightAmbient, lightAmbient, 1.00F };
	GLfloat light0Dif[4] = { lightDiffuse, lightDiffuse, lightDiffuse, 1.00F };
	GLfloat light0Spc[4] = { lightSpecular, lightSpecular, lightSpecular, 1.00F };
	glLightfv(GL_LIGHT0, GL_AMBIENT, light0Amb);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light0Dif);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light0Spc);
	glEnable(GL_LIGHT0);


	glEnable(GL_COLOR_MATERIAL);

	GLfloat matAmb[4] = { materialAmbient, materialAmbient, materialAmbient, 1.00F };
	GLfloat matDif[4] = { materialDiffuse, materialDiffuse, materialDiffuse, 1.00F };
	GLfloat matSpc[4] = { materialSpecular, materialSpecular, materialSpecular, 1.00F };
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, matAmb);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, matDif);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpc);

	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, materialShininess);
}

@end
