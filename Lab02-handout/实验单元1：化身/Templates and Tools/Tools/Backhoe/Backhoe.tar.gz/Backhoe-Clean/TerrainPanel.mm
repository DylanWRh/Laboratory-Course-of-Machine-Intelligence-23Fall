/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  TerrainPanel.mm

#import "TerrainPanel.h"


@implementation TerrainPanel

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

- (TerrainDocument*) terrain
{
	return mTerrain;
}

- (void) setTerrain: (TerrainDocument*)terrain
{
	mTerrain = terrain;
}

- (void) setMainWindow: (NSWindow *)mainWindow
{
    id document = [[mainWindow windowController] document];
	TerrainDocument *newTerrain = nil;
	
    if (document && [document isKindOfClass:[TerrainDocument class]]) {
        newTerrain = (TerrainDocument *)document;
    } else {
        newTerrain = nil;
    }
	
	[self setTerrain: newTerrain];
}

- (void) mainWindowChanged: (NSNotification *)notification
{
    [self setMainWindow: [notification object]];
}

- (void) mainWindowResigned: (NSNotification *)notification
{
    [self setMainWindow: nil];
}

- (void)windowDidLoad
{
    [super windowDidLoad];
	
    [self setMainWindow:[NSApp mainWindow]];
    [[NSNotificationCenter defaultCenter]
		addObserver: self selector: @selector(mainWindowChanged:)
		name: NSWindowDidBecomeMainNotification object :nil];
    [[NSNotificationCenter defaultCenter]
		addObserver: self selector:@selector(mainWindowResigned:)
		name: NSWindowDidResignMainNotification object: nil];
}

@end
