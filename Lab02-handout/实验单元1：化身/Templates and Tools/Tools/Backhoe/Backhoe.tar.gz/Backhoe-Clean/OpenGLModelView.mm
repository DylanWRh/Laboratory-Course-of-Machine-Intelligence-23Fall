/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  OpenGLModelView.mm

#import "OpenGLModelView.h"

void reportGLError(const char* stage)
{
	GLenum err = glGetError();
	if (err == GL_NO_ERROR) return;
	
	NSLog(@"reportGLError: (%s) %s", stage, gluErrorString(err));
}

@implementation OpenGLModelView

+ (NSOpenGLPixelFormat*) basicPixelFormat
{
    NSOpenGLPixelFormatAttribute attributes [] = {
        NSOpenGLPFAWindow,
        NSOpenGLPFADoubleBuffer,	// double buffered
        NSOpenGLPFADepthSize, (NSOpenGLPixelFormatAttribute)16, // 16 bit depth buffer
        (NSOpenGLPixelFormatAttribute)nil
    };
    return [[[NSOpenGLPixelFormat alloc] initWithAttributes:attributes] autorelease];
}

- (id)initWithFrame: (NSRect) frameRect
{
	NSOpenGLPixelFormat * pf = [OpenGLModelView basicPixelFormat];

	mGLSetup = false;
	mTargetSpinning = 1.0;
	mTargetForwardAngle = 0.0;
	mTargetFocusZoom = mCurrFocusZoom = 0;
	mTargetFocusPoint.x = mCurrFocusPoint.x = 128.0;
	mTargetFocusPoint.y = mCurrFocusPoint.y = 128.0;
	mTargetFocusPoint.z = mCurrFocusPoint.z = 0.0;
	mLastFocusAdjustment = 0;
	
	self = [super initWithFrame: frameRect pixelFormat: pf];
    return self;
}

- (void)setUpMatricies
{
	CFAbsoluteTime time = CFAbsoluteTimeGetCurrent();
	double delta = time - mLastFocusAdjustment;
	if (delta < 2) {
		double f = (1.0 - pow(0.1, delta));
		mCurrSpinning += f * (mTargetSpinning - mCurrSpinning);
		mCurrForwardAngle += f * (mTargetForwardAngle - mCurrForwardAngle);
		mCurrFocusZoom += f * (mTargetFocusZoom - mCurrFocusZoom);
		mCurrFocusPoint.x += f * (mTargetFocusPoint.x - mCurrFocusPoint.x);
		mCurrFocusPoint.y += f * (mTargetFocusPoint.y - mCurrFocusPoint.y);
		mCurrFocusPoint.z += f * (mTargetFocusPoint.z - mCurrFocusPoint.z);
	}
	mLastFocusAdjustment = time;

	NSRect r = [self bounds];
	
	glViewport(0, 0, r.size.width, r.size.height);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(55.0 - 15.0 * mCurrFocusZoom, r.size.width / r.size.height, 1.0, 1000.0);
	reportGLError("perspective");
	
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();
	

	GLdouble cenX, cenY, cenZ;
	cenX = mCurrFocusPoint.x;
	cenY = mCurrFocusPoint.y;
	cenZ = -25.0 + mCurrFocusZoom * 50.0 + mCurrFocusPoint.z;

	// rotate cenX, cenY about 128,128, mCurrForwardAngle degrees
	cenX -= 128.0, cenY -= 128.0;
	double sf = sin(mCurrForwardAngle * (M_PI / 180.0));
	double cf = cos(mCurrForwardAngle * (M_PI / 180.0));
	GLdouble newCenX, newCenY;
	newCenX = cf * cenX - sf * cenY;
	newCenY = sf * cenX + cf * cenY;
	cenX = newCenX + 128.0, cenY = newCenY + 128.0;

	GLdouble eyeX, eyeY, eyeZ;
	eyeX = 128.0;	// always down the middle line
	eyeY = -150.0 + mCurrFocusZoom * cenY;	// closer when zoomed
	eyeZ = 200.0 - mCurrFocusZoom * 50.0// lower when zoomed in
			+ mCurrFocusPoint.z;		// but adjust for height at selection

	gluLookAt(
		eyeX, eyeY, eyeZ,	// eye position
		cenX, cenY, cenZ,	// center point
		0.0, 0.0, 1.0		// up
		);
	reportGLError("camera");
	
	GLfloat angle = cos(fmod(time, 30.0) / 30.0 * 2.0 * M_PI) * 360.0;
		// every 30 seconds,
		// oscillate from + 1 rotation, to - 1 rotation and back again
	angle *= mCurrSpinning;
	angle *= (1.0 - mCurrFocusZoom);
	angle += mCurrForwardAngle;
	
	glTranslatef(128.0, 128.0, 0.0);
	glRotatef(angle, 0.0, 0.0, 1.0);
	glTranslatef(-128.0, -128.0, 0.0);
}

- (void) drawModel
{
}

- (void) drawRect:(NSRect)rect
{
    [[self openGLContext] makeCurrentContext];

	if (!mGLSetup) 
		[self prepareOpenGL];

	reportGLError("prepare");
		
	[self setUpMatricies];
	reportGLError("matricies");

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	[self drawModel];
	reportGLError("model");
	
	if ([self inLiveResize])
		glFlush ();
	else
		[[self openGLContext] flushBuffer];

	reportGLError("flush");
}

- (void) prepareOpenGL
{
	// set to vbl sync
    long swapInt = 1;
    [[self openGLContext] setValues: &swapInt
		forParameter: NSOpenGLCPSwapInterval];

	// init GL stuff here
	glEnable(GL_DEPTH_TEST);

	glShadeModel(GL_SMOOTH);    
//	glEnable(GL_CULL_FACE);
//	glFrontFace(GL_CCW);
	
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	mGLSetup = true;
}

- (void) awakeFromNib
{
	mTimer = [NSTimer timerWithTimeInterval: 1.0/60.0
		target: self selector: @selector(redrawTimer:)
		userInfo: nil repeats: YES];
	[[NSRunLoop currentRunLoop] addTimer: mTimer
		forMode: NSDefaultRunLoopMode];
	[[NSRunLoop currentRunLoop] addTimer: mTimer
		forMode: NSEventTrackingRunLoopMode];
		// ensure timer fires during resize
}

- (void) redrawTimer: (NSTimer*) timer
{
	if ([self inLiveResize])
		[self display];
	else
		[self setNeedsDisplay: YES];
}

- (void) rotateTo: (float)angleInDegrees;
{
	mTargetForwardAngle = angleInDegrees;
	
	float delta = mTargetForwardAngle - mCurrForwardAngle;
	if (delta > 180.0)			mCurrForwardAngle += 360.0;
	else if (delta < -180.0)	mCurrForwardAngle -= 360.0;
}

- (void) focusOn: (const Vector3f&)p
{
	mTargetFocusPoint = p;
	mTargetFocusZoom = 1.0;
}
	
- (void) unfocus
{
	mTargetFocusPoint.x = 128.0;
	mTargetFocusPoint.y = 128.0;
	mTargetFocusPoint.z = 0.0;
	mTargetFocusZoom = 0.0;
}

- (BOOL)spinning
{
	return mTargetSpinning != 0.0;
}

- (IBAction)toggleSpinning:(id)sender
{
	mTargetSpinning = (mTargetSpinning == 0.0) ? 1.0 : 0.0;
}

- (BOOL)validateMenuItem:(id <NSMenuItem>)item
{
	if ([item action] == @selector(toggleSpinning:)) {
		[item setState: [self spinning] ? NSOnState : NSOffState];
		return YES;
	}
	
	return YES;
}
@end
