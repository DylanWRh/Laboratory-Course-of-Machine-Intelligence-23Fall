/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  HeightEditor.h

#import <Cocoa/Cocoa.h>

@class EditPanel;
@class QCRenderer;
@class TerrainDocument;

@interface HeightEditor : NSView {
	IBOutlet EditPanel*		mPanel;
	IBOutlet NSTextField*	mHeightLine;
	
	NSAffineTransform* mTransform;
	NSAffineTransform* mInverseTransform;
	
	// these are only valid during an editing operation
	TerrainDocument* mDocument;
	
	NSBezierPath* mStroke;
	NSImage* mStrokeOriginal;
	NSImage* mStrokeImage;
	
	QCRenderer* mRenderer;
	NSOpenGLContext* mContext;
	
}

@end
