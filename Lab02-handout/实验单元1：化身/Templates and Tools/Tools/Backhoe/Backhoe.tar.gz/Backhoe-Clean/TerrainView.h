/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

// TerrainView.h

#import <Cocoa/Cocoa.h>

#import "OpenGLModelView.h"
#import "TerrainDocument.h"

class TerrainModel;

@interface TerrainView : OpenGLModelView {

	TerrainModel* mTerrain;
	
	IBOutlet TerrainDocument* mDocument;
	
}

- (void) drawModel;
- (void) prepareOpenGL;

@end
