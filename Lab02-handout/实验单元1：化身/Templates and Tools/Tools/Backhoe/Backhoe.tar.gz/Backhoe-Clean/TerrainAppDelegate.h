/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  TerrainAppDelegate.h

#import <Cocoa/Cocoa.h>


@interface TerrainAppDelegate : NSObject {

}

- (IBAction)deselect:(id)sender;
- (IBAction)selectTool:(id)sender;

- (IBAction)showEditPanel:(id)sender;
- (IBAction)showLightBox:(id)sender;

@end
