/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  EditPanel.mm

#import "EditPanel.h"
#import "TerrainDocument.h"

enum {
	ToolTag_Arrow		= 0,
	ToolTag_Dig			= 1,
	ToolTag_Build		= 2,
	ToolTag_Raise		= 3,
	ToolTag_Lower		= 4,
	ToolTag_Roughen		= 5,
	ToolTag_Flatten		= 6
};


@implementation EditPanel

+ (void)initialize {
    [self setKeys:[NSArray arrayWithObjects:@"toolValue", @"terrain", nil]
		triggerChangeNotificationsForDependentKey:@"toolHeight"];
    [self setKeys:[NSArray arrayWithObjects:@"toolHeight",nil]
		triggerChangeNotificationsForDependentKey:@"toolValue"];
    [self setKeys:[NSArray arrayWithObjects:@"tool",nil]
		triggerChangeNotificationsForDependentKey:@"toolHasWidth"];
    [self setKeys:[NSArray arrayWithObjects:@"tool",nil]
		triggerChangeNotificationsForDependentKey:@"toolHasFade"];
    [self setKeys:[NSArray arrayWithObjects:@"tool",nil]
		triggerChangeNotificationsForDependentKey:@"toolHasScale"];
    [self setKeys:[NSArray arrayWithObjects:@"tool",nil]
		triggerChangeNotificationsForDependentKey:@"toolHasHeight"];
}

+ (EditPanel*) sharedEditPanel
{
    static EditPanel *editPanel = nil;

    if (!editPanel) {
        editPanel = [[EditPanel alloc] init];
    }

    return editPanel;
}

- (id) init
{
    self = [self initWithWindowNibName:@"EditPanel"];
    if (self) {
		[self reset];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

- (void) reset
{
	mTool = 0;
	toolWidth = 10.0;
	toolFade = 3.0;
	toolScale = 5.0;
	toolValue = 0.25;
}

- (void) heightImageChanged: (NSNotification *)notification
{
	if ([notification object] == [self terrain]) {
		[mHeightEditor setNeedsDisplay: YES];
	}
}

- (void)windowDidLoad
{
    [super windowDidLoad];
	
    [mPanel setFloatingPanel: YES];
//	[mPanel setBecomesKeyOnlyIfNeeded: YES];
//	[mPanel setAcceptsMouseMovedEvents: YES];
	
    [[NSNotificationCenter defaultCenter]
		addObserver: self selector:@selector(heightImageChanged:)
		name: TerrainHeightImageChangedNotification object: nil];
}

- (NSUndoManager*)windowWillReturnUndoManager:(NSWindow *)sender
{
	return [[self terrain] undoManager];
}

- (void) deselect
{
	TerrainDocument* terrain = [self terrain];
	if (terrain)
		[terrain clearSelection];
}

- (int) tool
{
	return mTool;
}

- (void) setTool: (int)tag;
{
	mTool = tag;
}

- (float) toolHeight
{
	TerrainDocument* terrain = [self terrain];
	if (!terrain  ||  ![terrain heightMultiplyFactorIsUniform]) {
		return toolValue;
	}
	
	double multiplyFactor = [terrain heightMultiplyFactor]; 
	return toolValue * (255.0 * multiplyFactor);
}

- (void)  setToolHeight: (float) height
{
	TerrainDocument* terrain = [self terrain];
	if (!terrain  ||  ![terrain heightMultiplyFactorIsUniform]) {
		toolValue = height;
		return;
	}
	
	double multiplyFactor = [terrain heightMultiplyFactor]; 
	toolValue = height / (255.0 * multiplyFactor);
}

- (BOOL) toolHasWidth	{ return mTool != ToolTag_Arrow; }
- (BOOL) toolHasFade	{ return mTool != ToolTag_Arrow; }
- (BOOL) toolHasScale	{ return mTool == ToolTag_Roughen
							 ||  mTool == ToolTag_Flatten; }
- (BOOL) toolHasHeight	{ return mTool != ToolTag_Arrow
							 &&  mTool != ToolTag_Flatten; }

@end
