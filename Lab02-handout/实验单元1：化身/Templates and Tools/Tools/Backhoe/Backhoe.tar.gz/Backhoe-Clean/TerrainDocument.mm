/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  TerrainDocument.mm

#import "TerrainDocument.h"

NSString* TerrainHeightImageChangedNotification = @"TerrainHeightImageChanged";
NSString* TerrainSelectionChangedNotification = @"TerrainSelectionChanged";

namespace {
	const int LayerCount = 13;
	const NSSize LayerSize = { 256.0, 256.0 };
	const NSRect LayerBox = NSMakeRect(0.0, 0.0, 256.0, 256.0);

	const unsigned int LayerPixelCount = 256 * 256;
	const unsigned int LayerPixelBytes = 13;

	int LayerIndex(int i, int j) { return (255 - i) * 256 + j; }

	enum {
		Layer_HeightField					= 0,
		Layer_HeightMultiplyFactor			= 1,
		Layer_WaterHeight					= 2,
		Layer_LandParcels					= 3,
		Layer_ForSale						= 4,
		Layer_PublicEditObject				= 5,
		Layer_PublicEditLand				= 6,
		Layer_SafeLand						= 7,
		Layer_FlyingAllowed					= 8,
		Layer_CreateLandmark				= 9,
		Layer_OutsideScriptsAllowed			= 10,
		Layer_OriginalHeightField			= 11,
		Layer_OriginalHeightMultiplyFactor	= 12
	};
	
    NSString* imageDirectory = nil;

	NSBitmapImageRep* allocLayerBitmap()
	{
		return [[NSBitmapImageRep alloc]
				initWithBitmapDataPlanes: NULL
				pixelsWide: LayerSize.width
				pixelsHigh: LayerSize.height
				bitsPerSample: 8
				samplesPerPixel: 1
				hasAlpha: NO
				isPlanar: NO
				colorSpaceName: NSDeviceWhiteColorSpace
				bytesPerRow: 0
				bitsPerPixel: 0];
	}
}


@interface TerrainDocument (internal)

- (void)fillLayer:(int)i with: (unsigned char)v;
- (void)setLayer:(int)i to: (NSImage*) fromImage;
- (void)updateLayer:(int)i;

- (void)extractFromLayer:(int)i;
- (void)extractHeightMultiplyFactor;
- (void)extractWaterHeight;

@end


@implementation TerrainDocument

- (id)init
{
    self = [super init];
    if (self) {
    
        // Add your subclass-specific initialization here.
        // If an error occurs here, send a [self release] message and return nil.
		
		layerImages = [[NSMutableArray alloc] initWithCapacity: LayerCount];
		layerBitmaps = [[NSMutableArray alloc] initWithCapacity: LayerCount];
		
		for (int i = 0; i < LayerCount; ++i) {
			NSImage* image = [[NSImage alloc] initWithSize: LayerSize];
			NSBitmapImageRep* bitmap = allocLayerBitmap();
			
			[layerImages addObject: image];
			[layerBitmaps addObject: bitmap];
			
			[bitmap release];
			[image release];
		}
		
		mHeightMultiplyFactor = 0.0;
		mHeightMultiplyFactorUniform = true;
		mWaterHeight = 0;
		mRotation = 0.0;
		mSelection.selected = false;
    }
    return self;
}

- (void)dealloc
{
	[layerImages release];
	[super dealloc];
}

- (NSString *)windowNibName
{
    // Override returning the nib file name of the document
    // If you need to use a subclass of NSWindowController or if your document supports multiple NSWindowControllers, you should remove this method and override -makeWindowControllers instead.
    return @"TerrainDocument";
}

- (IBAction)toggleDrawer:(id)sender
{
	[mDrawer toggle: sender];
}

- (BOOL)validateMenuItem:(id <NSMenuItem>)item
{
	if ([item action] == @selector(toggleDrawer:)) {
		NSString* title;
		
		switch ([mDrawer state]) {
			case NSDrawerClosedState:
			case NSDrawerClosingState:
				title = NSLocalizedString(@"Open Info Drawer", @"");
				break;
				
			case NSDrawerOpenState:
			case NSDrawerOpeningState:
				title = NSLocalizedString(@"Close Info Drawer", @"");
				break;
		
			default:
				return NO;
		}
		
		[item setTitle: title];
		return YES;
	}
	
	return YES;
}


//- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError
- (NSData *)dataRepresentationOfType:(NSString *)aType
{
	unsigned int length = LayerPixelCount * LayerCount;
	void * buffer = malloc(length);
	
	for (int i = 0; i < LayerCount; ++i) {
		const unsigned char * src = [[layerBitmaps objectAtIndex: i] bitmapData];
		unsigned char * dest = (unsigned char *)buffer;
		
		dest += i;
		
		for (int j = 0; j < LayerPixelCount; ++j) {
			*dest = *src;
			src += 1;
			dest += LayerPixelBytes;
		}
	}

	return [NSData dataWithBytes: buffer length: length];
}

//- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError
- (BOOL)loadDataRepresentation:(NSData *)data ofType:(NSString *)aType
{
	if ([data length] != (LayerPixelCount * LayerCount)) {
		return NO;
	}
	for (int i = 0; i < LayerCount; ++i) {
		unsigned char * dest = [[layerBitmaps objectAtIndex: i] bitmapData];
		const unsigned char * src = (const unsigned char *)[data bytes];
		
		src += i;
		
		for (int j = 0; j < LayerPixelCount; ++j) {
			*dest = *src;
			dest += 1;
			src += LayerPixelBytes;
		}
		
		[self updateLayer: i];
		[self extractFromLayer: i];
	}
    return YES;
}

+ (void)initialize {
    [self setKeys:[NSArray arrayWithObjects:@"heightMultiplyFactor",@"heightMultiplyFactorIsUniform",nil]
    triggerChangeNotificationsForDependentKey:@"heightMultiplyFactorString"];
    [self setKeys:[NSArray arrayWithObjects:@"heightMultiplyFactor",@"heightMultiplyFactorIsUniform",@"layerImages",nil]
    triggerChangeNotificationsForDependentKey:@"heightData"];
    [self setKeys:[NSArray arrayWithObjects:@"layerImages",nil]
    triggerChangeNotificationsForDependentKey:@"heightImage"];
}

+ (BOOL)automaticallyNotifiesObserversForKey:(NSString *)theKey 
{
	if ([theKey isEqualToString: @"layerImages"]) return NO;
	return [super automaticallyNotifiesObserversForKey: theKey];
}



- (double)heightMultiplyFactor
{
	return mHeightMultiplyFactor;
}

- (void)setHeightMultiplyFactor:(double)factor
{
	mHeightMultiplyFactor = factor;
	
	if (mHeightMultiplyFactorUniform) {
		double v = floor(factor * 128.0) - 1.0;
		unsigned char pixel = (v < 0.0) ? 0 : (v <= 255.0) ? (int)v : 255;
		
		[self fillLayer: Layer_HeightMultiplyFactor with: pixel];
	}
}

- (BOOL)heightMultiplyFactorIsUniform
{
	return mHeightMultiplyFactorUniform ? YES : NO;
}

- (void)setHeightMultiplyFactorIsUniform:(BOOL)uniform
{
	mHeightMultiplyFactorUniform = uniform == YES;
}

- (NSString*)heightMultiplyFactorString
{
	return [NSString stringWithFormat: 
		mHeightMultiplyFactorUniform
			? NSLocalizedString(@"%5.3fx", @"")
			: NSLocalizedString(@"~ %5.3fx", @""),
		mHeightMultiplyFactor];
}

- (IBAction)makeHeightMultiplyFactorUniform:(id)sender
{
	[self setHeightMultiplyFactorIsUniform: YES];
	[self setHeightMultiplyFactor: mHeightMultiplyFactor];
}

- (int)waterHeight
{
	return mWaterHeight;
}

- (void)setWaterHeight: (int)h
{
	mWaterHeight = (h < 0) ? 0 : (h <= 255) ? h : 255;	
	[self fillLayer: Layer_WaterHeight with: (unsigned char)mWaterHeight];
}

- (Selection)selection
{
	return mSelection;
}

- (void)setSelection:(Selection)s
{
	mSelection = s;
	
	[[NSNotificationCenter defaultCenter]
		postNotificationName: TerrainSelectionChangedNotification
		object:self];
}

- (void)setSelectionTo:(NSPoint)p
{
	Selection s;
	s.selected = true;
	s.location = p;
	[self setSelection: s];
}

- (void)clearSelection
{
	Selection s;
	s.selected = false;
	[self setSelection: s];
}

- (float)rotation
{
	return mRotation;
}

- (void)setRotation:(float)r
{
	mRotation = r;
}

- (IBAction)rotateLeft:(id)sender
{
	[self setRotation: fmodf(mRotation + 90.0, 360.0)];
}

- (IBAction)rotateRight:(id)sender;
{
	[self setRotation: fmodf(mRotation - 90.0 + 360.0, 360.0)];
}

- (IBAction)rotateToNorth:(id)sender;
{
	[self setRotation: 0.0];
}


- (NSImage*)heightImage
{
	return [layerImages objectAtIndex: Layer_HeightField];
}

- (void)setHeightImage:(NSImage*)image
{
	[self setLayer: Layer_HeightField to: image ];
}


- (IBAction)exportLayer:(id)sender
{
	unsigned int i = [layerController selectionIndex];
	if (i == NSNotFound) return;
	
    NSSavePanel *sp = [NSSavePanel savePanel];
    [sp setRequiredFileType: @"png"];
    [sp setTitle: NSLocalizedString(@"Export Layer", @"")];
    [sp setCanSelectHiddenExtension: YES];
        
    NSString* name = [self displayName];
  
	// should realy be layer name, not number
	name = [name stringByAppendingFormat: @"-%d", i];

    int result = [sp runModalForDirectory: imageDirectory file: name];

    [imageDirectory release];
    imageDirectory = [[sp directory] retain];
	
	if (result != NSOKButton) return;
	
	NSString* filename = [sp filename];

	NSBitmapImageRep* bitmap = [layerBitmaps objectAtIndex: i];
    NSData *pngData =
        [bitmap representationUsingType: NSPNGFileType properties: nil];

    [pngData writeToFile: filename atomically: YES];
}

- (IBAction)importLayer:(id)sender
{
	unsigned int i = [layerController selectionIndex];
	if (i == NSNotFound) return;

	NSOpenPanel* op = [NSOpenPanel openPanel];
	
	int result = [op runModalForDirectory: imageDirectory
					file: nil
					types: [NSImage imageFileTypes]];
	
    [imageDirectory release];
    imageDirectory = [[op directory] retain];
	
	if (result != NSOKButton) return;


	NSString* filename = [[op filenames] lastObject];
	NSImage* image = [[NSImage alloc] initWithContentsOfFile: filename];
	if (!image) return;
	NSSize s = [image size];
	if (s.width != 256.0 || s.height != 256.0) return;
	
	[self setLayer: i to: image];
	[image release];
}


- (const unsigned char*)heightData
{
	return [[layerBitmaps objectAtIndex: Layer_HeightField] bitmapData];
}

- (const unsigned char*)multiplyData
{
	return [[layerBitmaps objectAtIndex: Layer_HeightMultiplyFactor] bitmapData];
}

- (float) heightAt: (NSPoint) p
{
	int i = (int)floor(p.y);
	int j = (int)floor(p.x);
	
	i = (i < 0) ? 0 : (i <= 255) ? i : 255;
	j = (j < 0) ? 0 : (j <= 255) ? j : 255;

	int index = LayerIndex(i,j);
	unsigned char h = [self heightData][index];
	unsigned char m = [self multiplyData][index];
	
	static float oneOver128 = 1.0 / 128.0;
	return (float)h * ((float)m + 1) * oneOver128;
}

- (void) setHeight: (float) v at: (NSPoint) p
{
	int i = (int)floor(p.y);
	int j = (int)floor(p.x);
	
	if (i < 0 || i > 255) return;
	if (j < 0 || j > 255) return;

	int index = LayerIndex(i,j);
	unsigned char m = [self multiplyData][index];
		
	v = 128.0 * v / ((float)m + 1);
	if (v < 0.0) v = 0.0;
	if (v > 255.0) v = 255.0;
	
	[[layerBitmaps objectAtIndex: Layer_HeightField] bitmapData][index] = v;
}


- (int) rawHeightAt: (NSPoint) p
{
	int i = (int)floor(p.y);
	int j = (int)floor(p.x);
	
	i = (i < 0) ? 0 : (i <= 255) ? i : 255;
	j = (j < 0) ? 0 : (j <= 255) ? j : 255;

	int index = LayerIndex(i,j);
	return [self heightData][index];
}

- (void)registerUndoEdit: (NSImage*) originalImage
{
	NSUndoManager* undoer = [self undoManager];
	[undoer registerUndoWithTarget: self
		selector: @selector(completeEdit:)
		object: originalImage];
	[undoer setActionName: NSLocalizedString(@"Height Edit", @"")];
}

- (void)completeEdit: (NSImage*) image
{
	[self registerUndoEdit: [self heightImage]];
	[self setHeightImage: image];
}

@end

@implementation TerrainDocument (internal)

- (void)fillLayer:(int)i with: (unsigned char)v
{
	unsigned char * dest = [[layerBitmaps objectAtIndex: i] bitmapData];

	for (int j = 0; j < LayerPixelCount; ++j) {
		*dest++ = v;
	}

	[self updateLayer: i];
}

- (void)setLayer:(int)i to: (NSImage*) image;
{
	NSBitmapImageRep* bitmap = [layerBitmaps objectAtIndex: i];

	[NSGraphicsContext saveGraphicsState];
	[NSGraphicsContext setCurrentContext:
		[NSGraphicsContext graphicsContextWithBitmapImageRep: bitmap]];
 
	[image drawInRect: LayerBox
		fromRect: LayerBox
		operation: NSCompositeCopy
		fraction: 1.0];
 
	[NSGraphicsContext restoreGraphicsState];

	[self updateLayer: i];
	[self extractFromLayer: i];
}


- (void)updateLayer:(int)i
{
	NSImage* image = [[NSImage alloc] initWithSize: LayerSize];

	NSBitmapImageRep* bitmap = [layerBitmaps objectAtIndex: i];
	NSImage* layer = [[NSImage alloc] initWithSize: LayerSize];
	[layer addRepresentation: bitmap];

	[image lockFocus];
	[layer drawInRect: LayerBox
		fromRect: LayerBox
		operation: NSCompositeCopy
		fraction: 1.0];
	[image unlockFocus];

	unsigned int selectionIndex = [layerController selectionIndex];
	NSIndexSet* indexes = [NSIndexSet indexSetWithIndex: i];
	[self willChange: NSKeyValueChangeSetting
		valuesAtIndexes: indexes forKey: @"layerImages"];

	[layerImages replaceObjectAtIndex: i withObject: image];
	
	[self didChange: NSKeyValueChangeSetting
		valuesAtIndexes: indexes forKey: @"layerImages"];
	[layerController setSelectionIndex: selectionIndex];
	
	[layer release];
	[image release];
	
	if (i == Layer_HeightField) {
		[[NSNotificationCenter defaultCenter]
			postNotificationName: TerrainHeightImageChangedNotification
			object: self];
	}
}

- (void)extractFromLayer: (int)i
{
	switch (i) {
		case Layer_HeightMultiplyFactor:
			[self extractHeightMultiplyFactor];
			break;
			
		case Layer_WaterHeight:
			[self extractWaterHeight];
			break;
			
		default:
			;
	}
}

- (void)extractHeightMultiplyFactor
{
	double factor = 0.0;
	bool uniform = true;
	
	const unsigned char * data =
		[[layerBitmaps objectAtIndex: Layer_HeightMultiplyFactor] bitmapData];

	unsigned int zeroZeroPixel = *data;

	for (int j = 0; j < LayerPixelCount; ++j) {
		unsigned int pixel = *data++;
		
		factor += pixel;
		uniform &= (pixel == zeroZeroPixel);
	}

	factor /=  LayerPixelCount;
	factor += 1.0;
	factor /= 128.0;
	
	mHeightMultiplyFactorUniform = false;
 	[self setHeightMultiplyFactor: factor];
	[self setHeightMultiplyFactorIsUniform: uniform];
}

- (void)extractWaterHeight
{
	NSBitmapImageRep* bitmap = [layerBitmaps objectAtIndex: Layer_WaterHeight];
	
	unsigned int zeroZeroPixel;
	[bitmap getPixel: &zeroZeroPixel atX: 0 y: 0];
	
	[self setWaterHeight: zeroZeroPixel];
}

@end


