/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  TerrainDocument.h

#import <Cocoa/Cocoa.h>

struct Selection
{
	bool		selected;
	NSPoint		location;
};

@interface TerrainDocument : NSDocument
{
	NSMutableArray*		layerImages;
	NSMutableArray*		layerBitmaps;
	
	double				mHeightMultiplyFactor;
	bool				mHeightMultiplyFactorUniform;
	
	int					mWaterHeight;
	
	Selection			mSelection;
	float				mRotation;
	
	IBOutlet NSArrayController*	layerController;
	
	IBOutlet NSDrawer*	mDrawer;
}

- (IBAction)toggleDrawer:(id)sender;

- (IBAction)exportLayer:(id)sender;
- (IBAction)importLayer:(id)sender;

- (double)heightMultiplyFactor;
- (void)setHeightMultiplyFactor:(double)factor;
- (BOOL)heightMultiplyFactorIsUniform;
- (void)setHeightMultiplyFactorIsUniform:(BOOL)uniform;

- (NSString*)heightMultiplyFactorString;
- (IBAction)makeHeightMultiplyFactorUniform:(id)sender;

- (int)waterHeight;
- (void)setWaterHeight:(int)h;

- (Selection)selection;
- (void)setSelection:(Selection)s;
- (void)setSelectionTo:(NSPoint)p;
- (void)clearSelection;

- (float)rotation;
- (void)setRotation:(float)r;
	// rotation is in degrees
- (IBAction)rotateLeft:(id)sender;
- (IBAction)rotateRight:(id)sender;
- (IBAction)rotateToNorth:(id)sender;


// for use by HeightEditor
- (NSImage*)heightImage;
- (void)setHeightImage:(NSImage*)image;
- (float) heightAt: (NSPoint)p;
- (void) setHeight: (float)h at: (NSPoint)p;
- (int) rawHeightAt: (NSPoint)p;

- (void)registerUndoEdit: (NSImage*) originalImage;
- (void)completeEdit: (NSImage*) image;

// for use by TerrainView - do not hold on to these pointers
- (const unsigned char*)heightData;
- (const unsigned char*)multiplyData;

@end

extern NSString* TerrainHeightImageChangedNotification;
extern NSString* TerrainSelectionChangedNotification;
extern NSString* TerrainRotationChangedNotification;
