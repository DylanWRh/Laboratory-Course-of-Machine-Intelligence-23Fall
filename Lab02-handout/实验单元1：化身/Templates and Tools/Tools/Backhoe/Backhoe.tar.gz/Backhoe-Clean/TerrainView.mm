/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  TerrainView.mm

#import "TerrainView.h"
#import "LightBox.h"

#include <GLUT/glut.h>

// things defined in BasicOpenGLView.m, but not exported in the .h file
extern "C" {
	GLenum glReportError (void);
}



class TerrainModel
{
public:
	TerrainModel(TerrainDocument* document)
		: mDocument(document), mCells(0),
			mConeDisplayList(0)
		{ }
	
	void computeCells();
	void draw();
	
private:
	TerrainDocument* mDocument;
	
	struct Cell
	{
		GLfloat color[4];
		GLfloat normal[3];
		GLfloat	vertex[3];
	};
	
	Cell* mCells;
	
	GLuint mConeDisplayList;
	
	GLint index(int i, int j) { return i * 256 + j; }
	
	void computeHeights();
	void computeNormals();
	void computeColors();
	
	GLfloat height(int i, int j);
		// only valid during computeCells()
};

void
TerrainModel::computeHeights()
{
	const unsigned char* heights = [mDocument heightData];
	const unsigned char* multipliers = [mDocument multiplyData];
	
	for (int i = 255; i >= 0; --i) {
		// the first row in the data are the maximum y value
		// hence, going through the maps, is going in decsending y
		
		for (int j = 0; j < 256; ++j) {
			const unsigned char h = *heights++;
			const unsigned char m = *multipliers++;

			static GLfloat oneOver128 = 1.0 / 128.0;
			
			Cell& c = mCells[index(i,j)];
			c.vertex[0] = j;
			c.vertex[1] = i;
			c.vertex[2] = (GLfloat)h * ((GLfloat)m + 1) * oneOver128;
		}
	}
}

void
TerrainModel::computeNormals()
{
	for (int i = 0; i < 256; ++i) {
		for (int j = 0; j < 256; ++j) {
			GLfloat hya = height(i-1, j);
			GLfloat hyb = height(i+1, j);
			GLfloat hxa = height(i, j-1);
			GLfloat hxb = height(i, j+1);

			Cell& c = mCells[index(i,j)];
			c.normal[0] = hxb - hxa;
			c.normal[1] = hyb - hya;
			c.normal[2] = 2.0f;
		}
	}
}



void
TerrainModel::computeColors()
{
	static int c0[3] = { 233, 232, 179 };
	static int c1[3] = { 96, 143, 58 };
	static int c2[3] = { 190, 201, 153 };
	static int c3[3] = { 243, 245, 246 };
	
	for (int i = 0; i < 256; ++i) {
		for (int j = 0; j < 256; ++j) {
			Cell& c = mCells[index(i,j)];

			GLfloat h = c.vertex[2];
			
			int* a;
			int* b;
			GLfloat f;
			
			static GLfloat oneOver20 = 1.0 / 20.0;
			
				 if (h <  0.0)	a = c0, b = c0, f = 1.0;
			else if (h < 20.0)	a = c0, b = c1, f = h * oneOver20;
			else if (h < 40.0)	a = c1, b = c2, f = (h - 20.0) * oneOver20;
			else if (h < 60.0)	a = c2, b = c3, f = (h - 40.0) * oneOver20;
			else				a = c3, b = c3, f = 0.0;
			
			GLfloat g = 1.0 - f;
			
			static GLfloat oneOver255 = 1.0 / 255.0;

			c.color[0] = (g * a[0] + f * b[0]) * oneOver255; 
			c.color[1] = (g * a[1] + f * b[1]) * oneOver255; 
			c.color[2] = (g * a[2] + f * b[2]) * oneOver255;
			c.color[3] = 1.0;
		}
	}
}

void 
TerrainModel::computeCells()
{
	glBindBuffer(GL_ARRAY_BUFFER, 1);
	glBufferData(GL_ARRAY_BUFFER,
		sizeof(GLfloat)*10*256*256,
		NULL,
		GL_STATIC_DRAW);
	mCells = (Cell*)glMapBuffer(GL_ARRAY_BUFFER, GL_READ_WRITE);
	
	computeHeights();
	computeNormals();
	computeColors();
	
	mCells = 0;
	glUnmapBuffer(GL_ARRAY_BUFFER);
}

GLfloat
TerrainModel::height(int i, int j)
{
	i = (i < 0) ? 0 : (i <= 255) ? i : 255;
	j = (j < 0) ? 0 : (j <= 255) ? j : 255;

	return mCells[index(i,j)].vertex[2];
}

void
TerrainModel::draw()
{
	glDisable(GL_CULL_FACE);
	glEnable(GL_NORMALIZE);
	
	glBlendFunc(GL_ONE, GL_ZERO);
	
	glInterleavedArrays(GL_C4F_N3F_V3F, 0, mCells);

	for (int i = 1; i < 256; ++i) {
		GLushort indicies[2*256];
		GLushort* ip = indicies;
		for (int j = 0; j < 256; ++j) {
			*ip++ = index(i,j);
			*ip++ = index(i-1,j);
		}
		glDrawElements(GL_QUAD_STRIP, 2*256, GL_UNSIGNED_SHORT, indicies);
	}

	GLfloat waterHeight = [mDocument waterHeight];
	glEnable(GL_CULL_FACE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(0.0, 0.4, 0.6, 0.6);
	glPushMatrix();
		glTranslatef(128.0, 128.0, waterHeight / 2.0 - 0.01);
			// the epsilon of -0.01 is to keep it from
			// looking bad with flat terrain at the same height
		glScalef(256.0, 256.0, waterHeight);
		glutSolidCube(1.0);
	glPopMatrix();
	
	Selection selection = [mDocument selection];
	if (selection.selected) {
		glPushMatrix();
			GLfloat h = [mDocument heightAt: selection.location];
			glTranslatef(selection.location.x, selection.location.y, h + 20.0);
			glRotatef(180.0, 0.0, 1.0, 0.0);

			if (mConeDisplayList == 0) {
				mConeDisplayList = glGenLists(1);
				glNewList(mConeDisplayList, GL_COMPILE);
				
				glColor4f(0.9, 0.2, 0.1, 0.6);

				GLUquadric* q = gluNewQuadric();
				gluQuadricDrawStyle(q, GLU_FILL);
				gluQuadricNormals(q, GLU_FLAT);
				gluQuadricOrientation(q, GLU_INSIDE);
				gluDisk(q, 0.0, 3.0, 10, 1);
				gluDeleteQuadric(q);

				glutSolidCone(3.0, 15.0, 10, 1);
				
				glEndList();
			}
			glCallList(mConeDisplayList);
			
		glPopMatrix();
	}
}




@implementation TerrainView

- (void) dealloc {
	[mDocument removeObserver: self forKeyPath: @"heightData"];
	[mDocument removeObserver: self forKeyPath: @"rotation"];
	[[NSNotificationCenter defaultCenter] removeObserver: self];
	
	delete mTerrain;
	
	[super dealloc];
}


- (void) drawModel
{
	glPushMatrix();
		glTranslatef(128.0, 128.0, 300.0);
		[[LightBox sharedLightBox] setLightsAndMaterial];
	glPopMatrix();

	mTerrain->draw();
}

- (void) prepareOpenGL
{
	[super prepareOpenGL];
	
	glEnable(GL_DEPTH_TEST);
	glDepthMask(GL_TRUE);
	
	glEnable(GL_BLEND);
	glShadeModel(GL_SMOOTH);
}

- (void)awakeFromNib
{
	mTerrain = new TerrainModel(mDocument);
	[[self openGLContext] makeCurrentContext];
	mTerrain->computeCells();

	[mDocument addObserver: self forKeyPath: @"heightData"
		options: 0 context: nil];
	[mDocument addObserver: self forKeyPath: @"rotation"
		options: 0 context: nil];

	[[NSNotificationCenter defaultCenter] addObserver: self
		selector: @selector(selectionNotification:)
		name: TerrainSelectionChangedNotification object: mDocument];
		
	[super awakeFromNib];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
	change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqualToString: @"heightData"]) {
		[[self openGLContext] makeCurrentContext];
		mTerrain->computeCells();
	}
	if ([keyPath isEqualToString: @"rotation"]) {
		[self rotateTo: [mDocument rotation]];
	}
}

- (void)selectionNotification:(NSNotification*)notice
{
	Selection selection = [mDocument selection];
	if (selection.selected) {
		Vector3f p;
		p.x = selection.location.x;
		p.y = selection.location.y;
		p.z = [mDocument heightAt: selection.location];
		
		[self focusOn: p];
	}
	else {
		[self unfocus];
	}
}

- (BOOL) acceptsFirstResponder
{
	return YES;
}


@end
