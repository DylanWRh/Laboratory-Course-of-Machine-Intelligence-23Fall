/*
 *  Backhoe -- http://www.notabene-sl.com/Backhoe/
 *      Copyright (c) 2006 Zarf Vantongerloo
 *      Licensed under the GNU General Public License, Version 2
 */

//  HeightEditor.mm

#import "HeightEditor.h"
#import "EditPanel.h"
#import "TerrainDocument.h"

#import <Quartz/Quartz.h>

static const NSString* HeightImagePath = @"terrain.heightImage";
static const NSString* RotationPath = @"terrain.rotation";


@interface HeightEditor (internal)

- (NSPoint)documentWhereFromEvent:(NSEvent*)event;
- (void)updateHeightStringFor:(NSPoint)where;
- (void)buildRenderer;
- (NSCursor*)buildToolCursor;
- (void)resetRotation;

@end


@implementation HeightEditor

- (void)awakeFromNib
{
	[mPanel addObserver: self forKeyPath: HeightImagePath
		options: 0 context: nil];
	[mPanel addObserver: self forKeyPath: RotationPath
		options: 0 context: nil];
	[mPanel addObserver: self forKeyPath: @"tool"
		options: 0 context: nil];
	[mPanel addObserver: self forKeyPath: @"toolWidth"
		options: 0 context: nil];
	[mPanel addObserver: self forKeyPath: @"toolFade"
		options: 0 context: nil];
	[[NSNotificationCenter defaultCenter] addObserver: self
		selector: @selector(selectionNotification:)
		name: TerrainSelectionChangedNotification object: nil];
	
	mTransform = [[NSAffineTransform transform] retain];
	mInverseTransform = [[NSAffineTransform transform] retain];
}

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver: self];
	[mPanel removeObserver: self forKeyPath: HeightImagePath];
	[mPanel removeObserver: self forKeyPath: RotationPath];
	[mPanel removeObserver: self forKeyPath: @"tool"];
	[mPanel removeObserver: self forKeyPath: @"toolWidth"];
	[mPanel removeObserver: self forKeyPath: @"toolFade"];
	[mTransform release];
	[mInverseTransform release];
	[super dealloc];
}



- (void)drawSelection:(NSPoint)where
{
	[[NSColor colorWithCalibratedRed: 0.9 green: 0.2 blue: 0.1 alpha: 0.6]
		set];
	
	const float r = 6.0;
	NSRect spotRect;
	spotRect.origin = where;
	spotRect.origin.x -= r;
	spotRect.origin.y -= r;
	spotRect.size = NSMakeSize(2*r, 2*r);
	
	NSBezierPath* circle = [NSBezierPath bezierPathWithOvalInRect: spotRect];
	[circle setLineWidth: 3.0];
	[circle stroke];
}


- (void)drawRect:(NSRect)rect
{
	NSImage* image = [[mPanel terrain] heightImage];
	// if (mStrokeImage) image = mStrokeImage;
	
	if (!image) {
		//NSEraseRect([self bounds]);
		return;
	}
	
	
	[NSGraphicsContext saveGraphicsState];
	[mTransform concat];

	NSRect bounds = [self bounds];
	[image drawInRect: bounds fromRect: bounds
		operation: NSCompositeCopy fraction: 1.0];

	if (!mStroke) {
		Selection selection = [[mPanel terrain] selection];
		if (selection.selected)
			[self drawSelection: selection.location];
	}
	
	[NSGraphicsContext restoreGraphicsState];
}

- (void)mouseDown:(NSEvent*)event
{
	mDocument = [mPanel terrain];
	if (!mDocument) return;
	
	NSPoint where = [self documentWhereFromEvent: event];
	[mDocument setSelectionTo: where];
	
	if ([mPanel tool] == 0) return;
	
	[self buildRenderer];
	if (!mRenderer) return;
	
	float toolWidth = mPanel->toolWidth;
	float toolFade = mPanel->toolFade;
	float toolScale = mPanel->toolScale;
	float toolValue = mPanel->toolValue;

	mStroke = [[NSBezierPath bezierPath] retain];
	[mStroke setLineCapStyle: NSRoundLineCapStyle];
	[mStroke setLineJoinStyle: NSRoundLineJoinStyle];
	[mStroke setLineWidth: toolWidth + 2.0 * toolFade ];
	[mStroke moveToPoint: where];
	
	NSSize s = { 256.0, 256.0 };
	mStrokeOriginal = [[mDocument heightImage] retain];
	mStrokeImage = [[NSImage alloc] initWithSize: s];
	
	[mStrokeImage lockFocus];
	[[NSColor blackColor] setFill];
	NSRectFill(NSMakeRect(0,0,256,256));
	[mStrokeImage unlockFocus];
	
	[mRenderer setValue: [NSNumber numberWithFloat: toolFade / 2.0]
		forInputKey: @"blurRadius"];
		
	if ([mPanel toolHasScale]) {
		[mRenderer setValue: [NSNumber numberWithFloat: toolScale]
			forInputKey: @"toolScale"];
	}
	if ([mPanel toolHasHeight]) {
		[mRenderer setValue: [NSNumber numberWithFloat: toolValue]
			forInputKey: @"toolValue"];
	}
	
	[mRenderer setValue: mStrokeOriginal
		forInputKey: @"originalImage"];

	[self mouseDragged: event];
}

- (void)mouseUp:(NSEvent*)event
{
	NSPoint where = [self documentWhereFromEvent: event];
	[mDocument setSelectionTo: where];
	
	if (mStroke) {
		[mDocument registerUndoEdit: mStrokeOriginal];
	
		mDocument = nil;
		
		[mStroke release];			mStroke = nil;
		[mStrokeOriginal release];	mStrokeOriginal = nil;
		[mStrokeImage release];		mStrokeImage = nil;

		[mRenderer release];		mRenderer = nil;
		[mContext release];			mContext = nil;
	}
}

- (void)mouseDragged:(NSEvent*)event
{
	NSPoint where = [self documentWhereFromEvent: event];
	[mDocument setSelectionTo: where];

	if (mStroke) {
		[mStroke lineToPoint: where];
		
		[mStrokeImage lockFocus];
		[[NSColor whiteColor] setStroke];
		[mStroke stroke];
		[mStrokeImage unlockFocus];

		[mRenderer setValue: mStrokeImage
			forInputKey: @"strokeImage"];
		[mRenderer renderAtTime: 0.0 arguments: nil];
		NSImage* newImage = [mRenderer valueForOutputKey: @"newImage"];

		[mDocument setHeightImage: newImage];
	}
}


- (void)resetCursorRects
{
	NSCursor* cursor =
		([mPanel tool] == 0)
			? [NSCursor crosshairCursor]
			: [self buildToolCursor];
	
	[self addCursorRect: [self bounds] cursor: cursor];
}


- (BOOL) acceptsFirstResponder
{
	return NO;
}

- (BOOL) acceptsFirstMouse: (NSEvent*) event
{
	return YES;
}

- (BOOL) mouseDownCanMoveWindow
{
	return NO;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
	change:(NSDictionary *)change context:(void *)context
{
	if ([keyPath isEqualToString: HeightImagePath]) {
		[self setNeedsDisplay: YES];
	}
	else if ([keyPath isEqualToString: RotationPath]) {
		[self resetRotation];
	}
	else {
		[[self window] invalidateCursorRectsForView: self];
	}
}

@end

@implementation HeightEditor (internal)

- (NSPoint)documentWhereFromEvent:(NSEvent*)event
{
	NSPoint where = [self convertPoint: [event locationInWindow] fromView :nil];
	NSPoint docWhere = [mInverseTransform transformPoint: where];
	return docWhere;
}


- (void)updateHeightStringFor:(NSPoint)where
{
	if (mDocument == nil) {
		[mHeightLine setStringValue: @""];
		return;
	}

	float height = [mDocument heightAt: where];
	int raw = [mDocument rawHeightAt: where];

	[mHeightLine setStringValue:
		[NSString stringWithFormat: NSLocalizedString(@"%4.1fm (%d)", @""),
			height, raw]];
}

- (void)selectionNotification:(NSNotification*)notice
{
	if ([notice object] != [mPanel terrain]) return;
	[self setNeedsDisplay: YES];
	[self updateHeightStringFor: [[mPanel terrain] selection].location];
}

- (void)resetRotation
{
	float r = 0.0;
	
	TerrainDocument* terrain = [mPanel terrain];
	if (terrain)
		r = [terrain rotation];
		
	NSRect bounds = [self bounds];
	float cx = NSMidX(bounds);
	float cy = NSMidY(bounds);

	[mTransform release];
	mTransform = [[NSAffineTransform transform] retain];	
	[mTransform translateXBy: cx yBy: cy];
	[mTransform rotateByDegrees: r];
	[mTransform translateXBy: -cx yBy: -cy];

	[mInverseTransform release];
	mInverseTransform = [[NSAffineTransform transform] retain];	
	[mInverseTransform appendTransform: mTransform];
	[mInverseTransform invert];
	
	[self setNeedsDisplay: YES];
}

- (void)buildRenderer
{
    NSOpenGLPixelFormatAttribute attributes [] = {
        NSOpenGLPFAPixelBuffer,
        NSOpenGLPFADepthSize, (NSOpenGLPixelFormatAttribute)8,
        (NSOpenGLPixelFormatAttribute)nil
    };
	NSOpenGLPixelFormat* format =
		[[NSOpenGLPixelFormat alloc] initWithAttributes: attributes];

	static NSArray* toolResources = nil;
	if (!toolResources) {
		toolResources = [[NSArray alloc] initWithObjects:
			@"",
			@"dig",
			@"build",
			@"raise",
			@"lower",
			@"roughen",
			@"smooth",
			nil
		];
	}
	
	NSString* name = [toolResources objectAtIndex: [mPanel tool]];
	NSString* composition = [[NSBundle mainBundle]
								pathForResource: name ofType: @"qtz"];
		
	mContext = [[NSOpenGLContext alloc]
					initWithFormat: format
					shareContext: nil];
	mRenderer = [[QCRenderer alloc]
					initWithOpenGLContext: mContext
					pixelFormat: format
					file: composition];
	
	[format release];
}

- (NSCursor*)buildToolCursor
{
	float w = mPanel->toolWidth;
	float f = mPanel->toolFade;
	
	float d = w + 2 * f;
	
	NSImage* spotImage = [[NSImage alloc] initWithSize: NSMakeSize(d, d)];
	
	[spotImage lockFocus];
		[[NSColor colorWithCalibratedRed: 0.9 green: 0.2 blue: 0.1 alpha: 0.3]
			set];
		
		[[NSBezierPath bezierPathWithOvalInRect: NSMakeRect(0, 0, d, d)] fill];
		
		float o = (d - w) / 2;
		[[NSBezierPath bezierPathWithOvalInRect: NSMakeRect(o, o, w, w)] fill];
	[spotImage unlockFocus];
	
	float r = d / 2;
	NSCursor* spotCursor = 
		[[NSCursor alloc] initWithImage: spotImage hotSpot: NSMakePoint(r, r)];
	
	[spotImage autorelease];
	[spotCursor autorelease];
	return spotCursor;
}


@end
