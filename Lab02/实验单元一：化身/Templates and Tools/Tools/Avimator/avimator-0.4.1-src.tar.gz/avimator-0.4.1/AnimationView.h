/*
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Copyright (C) 2006 by Vinay Pulim.
 * All rights reserved.
 *
 */

#ifndef ANIMATIONVIEW_H
#define ANIMATIONVIEW_H

#include <FL/Fl_Gl_Window.h>
#include "Animation.h"
#include "Camera.h"

#define MALE_BVH   "data/SLMale.bvh"
#define FEMALE_BVH "data/SLFemale.bvh"

class AnimationView : public Fl_Gl_Window {
public:
  typedef enum { MALE, FEMALE, NUM_FIGURES } FigureType;
  AnimationView(int x, int y, int w, int h, Animation *anim = 0);
  ~AnimationView();

  void setAnimation(Animation *anim);  
  Animation *getAnimation() { return animation; }
  bool isSkeletonOn() { return skeleton; }
  FigureType getFigure() { return figType; }
  void setFigure(FigureType type);
  void showSkeleton() { skeleton = true; }
  void hideSkeleton() { skeleton = false; }
  void selectPart(const char *part);
  const char *getSelectedPart();
  void getChangeValues(double *x, double *y, double *z);
  int handle(int event);

private:
  typedef enum { MODE_PARTS, MODE_SKELETON, MODE_ROT_AXES };
  static const char figureFiles[NUM_FIGURES][256];
  Animation *animation;
  int last_x, last_y;  
  Camera camera;
  double changeX, changeY, changeZ;
  BVHNode *joints[NUM_FIGURES];
  bool skeleton;
  bool selecting;
  int selectName;
  int partHighlighted;
  int partSelected;
  int partDragging;
  int dragX, dragY;
  int drawMode;
  bool xSelect, ySelect, zSelect;
  FigureType figType;

  void draw();
  void drawFloor();
  void drawFigure();
  void drawPart(int frame, BVHNode *motion, BVHNode *joints, int mode);
  void setProjection();
  void setModelView();
  void setBodyMaterial();
  void resetCamera();
  void clearSelected();
  int pickPart(int x, int y);
  void drawCircle(int axis, float radius, int width);
};

#endif
