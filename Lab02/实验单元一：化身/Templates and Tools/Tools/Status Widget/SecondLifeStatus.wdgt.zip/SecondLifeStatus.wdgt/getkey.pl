#!/usr/bin/perl -Tw

use strict;

{
	my ($firstName, $lastName) = ("n/a","n/a");
	$firstName = $ARGV[0] if @ARGV > 0;
	$lastName = $ARGV[1] if @ARGV > 1;

	my $cachefile = "$ENV{'HOME'}/Library/Application Support/SecondLife/cache/name.cache";

	open(FI,$cachefile) or die qq(couldn't open file $cachefile - $!);

	my $version = <FI>;

	if ( $version eq "version\t2\n" )
	{
		while (<FI>) {
			if (/^(.*)\t(.*)\t$firstName\t$lastName$/)
			{
				my $cw = $1;
				$cw =~ tr/0123456789abcdef/32107654ba98fedc/; 
	       			print $cw. "\n";
				exit 0;
			}
		}
	}
	else
	{
		
		while (<FI>) {
			tr/0123456789abcdef/32107654ba98fedc/; 
			if (/^(.*),$firstName\s$lastName$/)
			{
	       	         print $1 . "\n";
				exit 0;
			}
		}
	}
	close(FI);

	foreach $cachefile ("$ENV{'HOME'}/name2key.csv") {
		open(FI,$cachefile) or die qq(couldn't open file $cachefile - $!);

		while (<FI>) {
			if (/^(.*),$firstName\s$lastName$/)
			{
		                print $1 . "\n";
				exit 0;
			}
		}
		
		close(FI);
	}
}
1;
