var xmlrpc= null;
var xmlhttp = null;
var sv_xmlhttp = null;

var widgetVersion = "1.7";

try{
    var xmlrpc = importModule("xmlrpc");
}catch(e){
    reportException(e);
    alert("importing of xmlrpc module failed.");
    throw "importing of xmlrpc module failed.";
}

var widgetWidth = 308;
var widgetHeight = 378;

var debug = false;
var debug_mail = false;

var webTimer;
var dataTimer;
var svTimer;
var webRefresh = 1000 * 30; //web grab  default is 30 seconds
var dataRefresh = 1000 * 30; //data grab default is 30 seconds
var svRefresh = 1000 * 60 * 60 * 12; // every 24 hours check for new version
var metaData = null;
var serverKey = null;
    
var widgetOwner = "n/a";
var ownerEmail = "n/a";
var emailBridge = "n/a";
var simPosition = "n/a";

var service = null;

function send_rpc(method){
    var sString = method;
    var addr = "http://xmlrpc.secondlife.com/cgi-bin/xmlrpc.cgi";

    if ( window.widget && serverKey == null) 
    {
        serverKey = widget.preferenceForKey(makeKey("serverKey"));
    }
    
    if ( serverKey != null && service == null)
    {
        var params = {Channel : serverKey, StringValue : sString, IntValue : dataRefresh/1000};
        
        if (debug) alert("querying server : " + params.Channel + " : " + params.StringValue + " : " + params.IntValue);
        
        service = new xmlrpc.ServiceProxy(addr,['llRemoteData']);
        var callback = function(result,err){
            if (result != null) {
                
                if (debug) alert("String Result: " + result["StringValue"].split("\n"));  // Returns String Value
                if (debug) alert("Integer Result: " + result["IntValue"]);  // Returns Int Value
                setServerText(result["IntValue"],result["StringValue"].split("\n"));
            } else {
                reportException(err);
            }
        }
        
        try{
            service.llRemoteData(params, callback);
        }catch(e){
            reportException(e);
        }
    }
    service = null;
    return false;
}

function setServerText(code, values)
{
    if ( debug ) alert("setServerText called: " + code + ":" + values);
    
    if ( code == 1 ) 
    {
        metaData = values;  
        if (debug_mail) alert('<a href=\'secondlife://' + metaData[1] + '/' + metaData[6] + '\'>');
        document.getElementById('meta').innerHTML = 
            '<a href=\'secondlife://' + metaData[1] + '/' + metaData[6] + '\'>' + metaData[1] + " - " + metaData[3] + "</a><br>" + metaData[2];
        widgetOwner = metaData[0];
        ownerEmail = metaData[4];
        emailBridge = metaData[5];
        simPosition = metaData[6];
	
	if (debug_mail) alert('owner: ' + widgetOwner + '\nOwner email: ' + ownerEmail);
    }
    else if ( code == 2 ) 
    {
	var day = 0;
	var cloudy = 0;
	
        simData = values;
	var hour = simData[0].split(":")[0];
	var clouds = simData[4].split("%")[0];
	var speed = simData[3].split(" ")[0];
	
	if ( 6 < hour < 18 )
	{
		day = 1;
	}
	
	if ( clouds >= 50 )
	{
		cloudy = 1;
	}
        
	document.getElementById('time').innerHTML = simData[0];
        document.getElementById('fps').innerHTML = simData[1];
        document.getElementById('dialation').innerHTML = simData[2];
        document.getElementById('wind').innerHTML = simData[3];
        document.getElementById('cloudy').innerHTML = simData[4];
	
	
	var img = "Images/Invisible.png";
	
	if ( cloudy && day ) 
	{
		img = "120px-Cloudy01.svg.png";
	} 
	else if ( cloudy && ! day)
	{
		img = "120px-Cloudy01.svg.png";
	}
	else if ( ! cloudy && day )
	{
		img = "120px-Sun01.svg.png";
	}
	else if ( ! cloudy && ! day )
	{
		img = "120px-Moon02.svg.png";
	}
	
	document.getElementById('weathericon').innerHTML = "<img src='Images/" + img + "' alt='" + simData + " width='25' height='25'/>";
	
	var windTable = "<table cellpadding='0'>";
	for (var i = 3; i >= 0; --i) 
	{
		windTable = windTable + "<tr><td";
		if ( i*5 <= speed )
		{
			windTable = windTable + " bgcolor='ltgreen' ";
		}
		else
		{
			windTable = windTable + " bgcolor='grey' ";
		}
		windTable = windTable + "/><img height='2' width='10' src='Images/Invisible.png'/></td></tr>";
	}
	
	document.getElementById('windtable').innerHTML = windTable + "<tr bgcolor='white'><th bgcolor='white'>wind</th></tr></table>";
	
	var color = "ltgreen";
	var bars = 4;
	if ( .98 < simData[2] < .99  ) 
	{
		color = "yellow";
		bars = 3;
	}
	else if ( simData[2] <= .98 )
	{
		color = "red";
		bars = 2;
	}
	
	var dialTable = "<table cellpadding='0'>";
	for (var i = 3; i >=0; --i)
	{
		if ( bars > i )
		{
			dialTable = dialTable + "<tr><td bgcolor='" + color + "'><img height='2' width='10' src='Images/Invisible.png'/></td></tr>";
		}
		else
		{
			dialTable = dialTable + "<tr><td bgcolor='grey'><img height='2' width='10' src='Images/Invisible.png'/></td></tr>";
		}
	}
	document.getElementById('dialtable').innerHTML = dialTable + "<tr><th>dial.</th></tr></table>";
    }
    else if ( code = 3 )
    {
        visitData = values;
        document.getElementById('visitors').innerHTML = visitData[0];
    } else {
        document.getElementById('meta').innerHTML = "<a href='secondlife://Carmine/112/128'\">Get the ingame widget server</a>"
                                + " to see interesting data from your location";
    }
}
// utility for debugging
function dump_props(obj, obj_name) {
   var result = "";
   for (var i in obj) {
      result += obj_name + "." + i + " = " + obj[i] + "\n"
   }
   alert(result);
}

function IMName(form) {
    document.getElementById('imstatus').innerHTML = "status... data = " + widgetOwner + ", " + ownerEmail + ", " + emailBridge;
    
    if ( debug_mail ) alert ("status...data = " + widgetOwner + ", " + ownerEmail + ", " + emailBridge);
    
    
    if ( widgetOwner != "n/a" && ownerEmail != "n/a" && emailBridge != "n/a")
    {
	
	var user = form.imuser.value;
	var mess = form.immessage.value;
	
	if ( debug_mail ) alert ( "Sending message to " + user ) ;
	
        var result = widget.system('getkey.pl ' + user, null).outputString;
        document.getElementById('imstatus').innerHTML = "Message to " + user + " (" + result + ")";
        // send mail here..
        var mail = 'mail -s "' + result + '" '
                + emailBridge 
                + '@lsl.secondlife.com -F "'
                + widgetOwner + '" -f ' + ownerEmail + " << END\n"
                + mess + "\nEND\n";
       if ( debug_mail ) alert ( mail ) ;
       result = widget.system(mail, null).outputString;
       if ( debug_mail ) document.getElementById('imstatus').innerHTML = "Mail send result: " + result;
       form.immessage.value = '';
       form.imuser.value = '';
	
       
    } else {
        document.getElementById('im-status').innerHTML = "You need a widget server to enable this functionality : " + widgetOwner +":"+ ownerEmail +":"+ emailBridge;
    }
}

function get_sv_data() {
    
    if ( sv_xmlhttp == null ) {
        var addr = "http://www.sweetvitriol.com/status.xml";
        document.getElementById('sv-status').innerHTML = "v" + widgetVersion;
    
        sv_xmlhttp = new XMLHttpRequest();
        sv_xmlhttp.onreadystatechange=function() {
            if (sv_xmlhttp.readyState==4) {
                if ( debug ) alert(sv_xmlhttp.responseText);
                    var sv_response = sv_xmlhttp.responseXML.documentElement;
                    if ( sv_response != null ) {
                        var vers = sv_response.getElementsByTagName('widget-version')[0].firstChild.data ;
                        var latestSeverVersion = sv_response.getElementsByTagName('server-version')[0].firstChild.data
                        if (debug ) alert("version: " + vers);
                        if ( widgetVersion < vers ) {
                            document.getElementById('sv-status').innerHTML = "<image src='Images/alert.gif'/> <font color=red>v" + widgetVersion 
                                                                    + "</font><span>Alert:  Your widget is out of date. <p>"
                                                                    + "  The latest version: " + sv_response.getElementsByTagName('widget-version')[0].firstChild.data
                                                                    + ".<br>  Your version: " + widgetVersion
                                                                    + ".<p>  " + sv_response.getElementsByTagName('message')[0].firstChild.data
                                                                    + ".<p>  Update at your convenience.  Thanks!</span>";
                        } 
                        sv_xmlhttp = null;
                }
            }
        }
        sv_xmlhttp.open("GET",addr,true);
        sv_xmlhttp.send(null);
    }
    clearTimeout(svTimer); // There was the possibility of problems,better safe than sorry.
    svTimer = setTimeout('get_sv_data()',svRefresh);
}

function get_xmldata() {
    
    if ( xmlhttp == null ) {
        var addr = "http://secondlife.com/xmlhttp/secondlife.php";
        
        document.getElementById('signups').innerHTML = "loading...";
        document.getElementById('transactions').innerHTML = "loading...";
        document.getElementById('inworld').innerHTML = "loading...";
	document.getElementById('last_60').innerHTML = "loading...";
        
        xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState==4) {
                if ( debug ) alert(xmlhttp.responseText);
                var response = xmlhttp.responseXML.documentElement;
                if ( response != null ) {
                    document.getElementById('signups').innerHTML = response.getElementsByTagName('signups')[0].firstChild.data;
                    document.getElementById('last_60').innerHTML = response.getElementsByTagName('logged_in_last_60')[0].firstChild.data;
                    document.getElementById('transactions').innerHTML = response.getElementsByTagName('transactions')[0].firstChild.data;
                    document.getElementById('inworld').innerHTML = response.getElementsByTagName('inworld')[0].firstChild.data;
                    xmlhttp = null;
                }
            }
        }
        xmlhttp.open("GET",addr,true);
        xmlhttp.send(null);
    }
}

function refresh_friends() {
    parent.friends.location.href="http://secondlife.com/community/friends-inner.php";
}

function makeKey(key)
{
	return widget.identifier + "-" + key;
}

function stop() 
{
    if ( debug) alert("stopping");
    clearTimeout(dataTimer);
    clearTimeout(webTimer);
}

function run() 
{
    doWebGrab();
    get_sv_data();
    doDataServer();
}

function doDataServer()
{
    if ( serverKey != null ) {
        if ( metaData == null ) {
            send_rpc("meta");  
        }
        send_rpc("sim");
        send_rpc("visitors");
    } else {
        document.getElementById('meta').innerHTML = "<a href='secondlife://Carmine/112/128'\">Get the ingame widget server</a>"
                                + " to see interesting data from your location";
    }
    clearTimeout(dataTimer); // There was the possibility of problems,better safe than sorry.
    dataTimer = setTimeout('doDataServer()',dataRefresh);
}



function doWebGrab()
{
    get_xmldata();
    refresh_friends();
    clearTimeout(webTimer); // There was the possibility of problems,better safe than sorry.
    webTimer = setTimeout('doWebGrab()',webRefresh);
}

function setup(x,y)
{
	if(window.widget)
	{
        if (debug) alert("setup called for widget");
        window.resizeTo(widgetWidth, widgetHeight);
        if ( window.widget ) 
        {
            serverKey = widget.preferenceForKey(makeKey("serverKey"));
            document.getElementById('serverKey').value = serverKey;
            
            webRefresh = widget.preferenceForKey(makeKey("webRefresh"));
            document.getElementById('webRefresh').value = webRefresh/1000;
            
            dataRefresh = widget.preferenceForKey(makeKey("dataRefresh"));
            document.getElementById('dataRefresh').value = dataRefresh/1000;
        }
	}
    run();
}


function changeKey(elem)
{	
    if (debug) alert("setting server key - got here: " + elem.id);
    stop();
    if ( elem.id == "serverKey" ) 
    {
        serverKey = document.getElementById("serverKey").value;	// the frame element is obtained
          
        if(window.widget)
        {
            if (debug) alert("setting server key to " + serverKey);
            widget.setPreferenceForKey(serverKey,makeKey("serverKey"));
        }
    }
    else if ( elem.id == "dataRefresh" )
    {
        dataRefresh = 1000 * document.getElementById("dataRefresh").value;	// the frame element is obtained
        if (dataRefresh < 10000) dataRefresh = 10000;
        if (debug) alert("setting data refresh to " + dataRefresh);
        if(window.widget)
        {
            
            widget.setPreferenceForKey(dataRefresh,makeKey("dataRefresh"));
        }
        else
        {
            alert("oops, got here, panic");
        }
    }
    else if ( elem.id == "webRefresh" )
    {
        webRefresh = 1000 * document.getElementById("webRefresh").value;	// the frame element is obtained
        if (webRefresh < 5000)
            webRefresh = 5000;
        if (debug) alert("setting webRefresh to " + webRefresh);
        if(window.widget)
        {
            
            widget.setPreferenceForKey(webRefresh,makeKey("webRefresh"));
        }
    }
}  


// onremove clears away any preferences that this widget may have had.

function onremove()
{
    stop();
    if (debug) alert("onremove()");
    
    widget.setPreferenceForKey(null,makeKey("serverKey"));
    widget.setPreferenceForKey(null,makeKey("webRefresh"));
    widget.setPreferenceForKey(null,makeKey("dataRefresh"));
}

function onshow()
{
   if (debug) alert("onshow()"); 
   window.resizeTo(widgetWidth, widgetHeight);
   run();
}

function onhide()
{
    if (debug) alert("onhide()");
    stop();
}

// this is where widget-specific handlers can be declared.  This widget only uses one;
// it is called when the widget is removed from Dashbaord

if(window.widget)
{
    widget.onremove = onremove;
    widget.onshow = onshow;
    widget.onhide = onhide;
}